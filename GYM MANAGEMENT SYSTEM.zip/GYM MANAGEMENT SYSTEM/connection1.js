var mysql=require('mysql2')
var connection=mysql.createConnection(
  {
     host:'localhost',
     user:'root',
     password:'Pass@123'
   }
);
connection.connect(function (err){
   if (err) throw err;
   else
    console.log("connection successful....")
})
sql="create database prajesh";
connection.query(sql);