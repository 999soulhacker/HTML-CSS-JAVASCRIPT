var http = require('http');
var fs = require('fs');
var path = require('path');
var url = require('url');
var querystring = require('querystring');
var connection = require('./connection'); // MySQL connection

http.createServer(function (req, res) {
    var parsedURL = url.parse(req.url, true);
    var pathname = parsedURL.pathname;

    if (req.method === 'GET') {
        // Serve static files like HTML, CSS, JS
        if (pathname === "/") pathname = "/index.html";
        var filePath = path.join(__dirname, pathname.slice(1)); // remove "/" and resolve path
        var ext = path.extname(filePath).slice(1);

        const mimeType = {
            html: 'text/html',
            css: 'text/css',
            js: 'text/javascript'
        };
        var contentType = mimeType[ext] || 'text/plain';

        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(404, { 'Content-Type': 'text/html' });
                res.end("<h1>404 - File Not Found</h1>");
            } else {
                res.writeHead(200, { 'Content-Type': contentType });
                res.end(data);
            }
        });
    }

    else if (req.method === 'POST') {
        let body = "";
        req.on('data', chunk => {
            body += chunk.toString();
        });

        req.on('end', () => {
            const formData = querystring.parse(body);

            // Handle Signup
            if (pathname === "/signup") {
                const { username, password } = formData;
                const sql = "INSERT INTO user (username,password) VALUES (?, ?)";
                connection.query(sql, [username, password], (err, result) => {
                    if (err) {
                        res.writeHead(500, { 'Content-Type': 'text/html' });
                        return res.end("Error while signing up.");
                    }
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.end("<h1>SignUp Successful</h1><a href='/login.html'>Go to Login</a>");
                });
            }

            // Handle Login
            else if (pathname === "/login") {
                const { username, password } = formData;
                const sql = "SELECT * FROM user WHERE username= ? AND password = ?";
                connection.query(sql, [username, password], (err, results) => {
                    if (err) {
                        res.writeHead(500, { 'Content-Type': 'text/html' });
                        return res.end("Login failed.");
                    } else if (results.length > 0) {
                        res.writeHead(200, { 'Content-Type': 'text/html' });
                        res.end("<h1>Login successful</h1><a href='/index.html'>Go to Home</a>");
                    } else {
                        res.writeHead(401, { 'Content-Type': 'text/html' });
                        res.end("<h1>Invalid username or password</h1><a href='/login.html'>Try Again</a>");
                    }
                });
            }

            else {
                res.writeHead(404, { 'Content-Type': 'text/html' });
                res.end("404 - Unknown endpoint");
            }
        });
    }

}).listen(7865);

console.log("Server running at http://localhost:7865/");