var mysql=require('mysql2')
var connection=mysql.createConnection(
  {
     host:'localhost',
     user:'root',
     password:'Pass@123',
     database:'logindb'
   }
);
connection.connect(function (err){
   if (err) throw err;
   else
    console.log("connection successful....")
})
module.exports=connection;