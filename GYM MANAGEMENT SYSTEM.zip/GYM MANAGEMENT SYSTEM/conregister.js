const http = require('http');
const fs = require('fs');
const url = require('url');
const querystring = require('querystring');
const connection = require('./connection'); // Ensure this module exports a valid MySQL connection

http.createServer((req, res) => {
    const parsedURL = url.parse(req.url, true);
    const pathname = parsedURL.pathname;

    if (req.method === 'POST' && pathname === '/submit-enquiry') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });

        req.on('end', () => {
            const formData = querystring.parse(body);
            const { name, email, phone, message } = formData;

            const sql = 'INSERT INTO enquiries (name, email, phone, message) VALUES (?, ?, ?, ?)';
            connection.query(sql, [name, email, phone, message], (err, result) => {
                if (err) {
                    res.writeHead(500, { 'Content-Type': 'text/plain' });
                    res.end('Database error');
                    return;
                }

                res.writeHead(200, { 'Content-Type': 'text/plain' });
                res.end('Enquiry submitted successfully!');
            });
        });
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Page not found');
    }
}).listen(3000, () => {
    console.log('Server running at http://localhost:3000/');
});
